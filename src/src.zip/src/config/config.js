export const api_token = {
  token: "fyLvFPNHSQUtxJX2sPsq7g",
};
